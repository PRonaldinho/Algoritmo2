package examples.jarras;

import framework.BreadthFirstEngine;
import framework.DepthFirstEngine;
import framework.IterativeDeepeningEngine;

public class appJarras {

	public static void main(String args[]) {
		
		ProblemaJarras p = new ProblemaJarras();
		BreadthFirstEngine<EstadoJarras,ProblemaJarras> motorBfs = new BreadthFirstEngine<EstadoJarras,ProblemaJarras>();
		motorBfs.setProblem(p);
		motorBfs.performSearch();
		motorBfs.report();
		
		ProblemaJarras p2 = new ProblemaJarras();
		IterativeDeepeningEngine <EstadoJarras,ProblemaJarras> motorID = new IterativeDeepeningEngine <EstadoJarras,ProblemaJarras>();
		motorID.setProblem(p2);
		motorID.performSearch();
		motorID.report();
		
		ProblemaJarras p3 = new ProblemaJarras();
		DepthFirstEngine <EstadoJarras,ProblemaJarras> motorDfs = new DepthFirstEngine <EstadoJarras,ProblemaJarras>();
		motorDfs.setProblem(p3);
		motorDfs.performSearch();
		motorDfs.report();
	}
}
